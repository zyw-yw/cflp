export const SOCKETIO_URL = "http://127.0.0.1:5000";
export const MAPBOX_STYLESHEET_LOCATION = "mapbox://styles/mapbox/streets-v11"
export const MAPBOX_START_ZOOM = 13;
export const MAPBOX_START_CENTER = [73.96282648393901, 18.575329095213778];
export const API_URL = "http://localhost:5000";