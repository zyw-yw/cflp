import React from 'react'

export default function ConnectionStats() {
  return (
    <div>
      
    </div>
  )
}
