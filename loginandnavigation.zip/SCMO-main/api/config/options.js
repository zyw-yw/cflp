module.exports = {
    CODESTRING : "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
    CODELENGTH : 8,
    TRANSFER_STATUS : {
        PENDING : "pending",
        ONGOING : "ongoing",
        COMPLETED : "completed" 
    }
};